<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>SIPTEK-CRUD OBAT</title>

    <style>
        .btn-hover:hover{
            background-color: white;
            color: rgb(39, 39, 249) !important;
        }
    </style>

    <script>
        const routes = {
            adminMenu: <?php echo json_encode(route('login'), 15, 512) ?>,
            CRUDObat: <?php echo json_encode(route('admin.CRUDObat'), 15, 512) ?>,
            CRUDMitra: <?php echo json_encode(route('CRUDMitra.index'), 15, 512) ?>,
        };
    </script>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-primary">
        <div class="container-fluid" style="font-family: Arial, Helvetica, sans-serif;">
            <a class="navbar-brand" href="<?php echo e(route('adminMenu')); ?>">
                <img src="<?php echo e(asset('img/rshdLogo.png')); ?>" alt="logo" width="70" height="70">
                <span class="fw-bold fs-1" style="color: white; font-family: Arial, Helvetica, sans-serif; padding-top: 10px;">SiPTEK</span>
            </a>

            <!--NAVBAR-->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <button type="button" class="btn  me-3 btn-hover fs-5 fw-bold" style="color: white" onclick="window.location.href= routes.CRUDMitra">MITRA</button>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="btn me-3 btn-hover fs-5 fw-bold" style="color: white;" onclick="window.location.href= routes.CRUDObat">OBAT</button>
                    </li>
                    <li class="nav-item">
                        <?php if(Auth::check()): ?>
                        <a href="#" class="btn me-3 btn-hover fs-5 fw-bold" style="color: white;"
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            LOGOUT
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h1 class="text-center fw-bold">OBAT</h1>
    </div>

    <!--BUTTON TAMBAH OBAT-->
    <div class="container d-flex justify-content-end">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">Add New</button>
    </div>

<!-- MODAL TAMBAH OBAT -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.CRUDObat.submit')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Tambah Obat Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Nama Obat -->
                    <div class="mb-3">
                        <label for="namaObatBaru" class="form-label">Nama Obat</label>
                        <input type="text" id="namaObatBaru" name="nama_obat" class="form-control" placeholder="Masukkan nama obat" required>
                    </div>
                    <!-- Deskripsi -->
                    <div class="mb-3">
                        <label for="deskripsiObat" class="form-label">Deskripsi</label>
                        <textarea id="deskripsiObat" name="deskripsi" class="form-control" rows="3" placeholder="Masukkan deskripsi obat" required></textarea>
                    </div>
                    <!-- URL Gambar -->
                    <div class="mb-3">
                        <label for="foto" class="form-label">Upload Gambar</label>
                        <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

    <!-- TABLE OBAT-->    
    <div class="container mt-5" style="font-family: Arial, Helvetica, sans-serif;">
        <table class="table table-bordered table-striped" id="obatTable">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Obat</th>
                    <th scope="col">Deskripsi</th>
                    <th scope="col">Gambar</th>
                    <th scope="col" colspan="2" class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($obats)): ?>
                    <td colspan = "5" class="text-center table-warning">Tidak Ada Data</td>
                <?php else: ?>
                    <?php $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                    <td><?php echo e($obat->id); ?></td>
                    <td><?php echo e($obat->nama_obat); ?></td>
                    <td><?php echo e($obat->deskripsi); ?></td>
                    <td>
                        <?php if($obat->foto): ?>
                        <img src="<?php echo e(asset('storage/' .$obat->foto)); ?>" alt="Foto" style="height: 150px;">
                    <?php else: ?>
                        Tidak ada foto
                    <?php endif; ?>
                    </td>
                        <td>

                            <div class="container d-flex justify-content-end">
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($obat['id']); ?>">Edit</button>
                            </div>

                            <!-- MODAL EDIT OBAT -->
                            <div class="modal fade" id="editModal<?php echo e($obat['id']); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($obat['id']); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('admin.CRUDObat.update', $obat['id'])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editModalLabel<?php echo e($obat['id']); ?>">Edit Obat</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <!-- Nama Obat -->
                                                <div class="mb-3">
                                                    <label for="namaObatBaru<?php echo e($obat['id']); ?>" class="form-label">Nama Obat</label>
                                                    <input type="text" id="namaObatBaru<?php echo e($obat['id']); ?>" name="nama_obat" class="form-control" value="<?php echo e($obat['nama_obat']); ?>" required>
                                                </div>
                                                <!-- Deskripsi -->
                                                <div class="mb-3">
                                                    <label for="deskripsiObat<?php echo e($obat['id']); ?>" class="form-label">Deskripsi</label>
                                                    <textarea id="deskripsiObat<?php echo e($obat['id']); ?>" name="deskripsi" class="form-control" rows="3" required><?php echo e($obat['deskripsi']); ?></textarea>
                                                </div>
                                                <!-- URL Gambar -->
                                                <div class="mb-3">
                                                    <label for="urlGambarObat<?php echo e($obat['id']); ?>" class="form-label">URL Gambar</label>
                                                    <input type="url" id="urlGambarObat<?php echo e($obat['id']); ?>" name="url_gambar" class="form-control" value="<?php echo e($obat['url_gambar']); ?>" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            
                        <form action="<?php echo e(route('admin.CRUDObat.destroy', $obat['id'])); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-secondary" 
                                        onclick="return confirm('Are you sure you want to delete this item?');">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                
                <!-- <tr>
                    <th scope="row">1</th>
                    <td>Paracetamol</td>
                    <td>
                        <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"> Detail</button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" onclick="editObat(1, 'Paracetamol')" data-bs-toggle="modal" data-bs-target="#editModal">Edit</a></li>
                            <li><a class="dropdown-item" href="#" >Delete</a></li>
                        </ul>
                    </td>
                </tr> -->
            </tbody>
        </table>
    </div>

    <!-- MODAL EDIT OBAT-->
    <!-- <div class="modal" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Obat</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editObatId">
                <input type="text" id="editNamaObat" class="form-control" placeholder="Nama Obat">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="simpanEditObat()">Save Changes</button>
            </div>
        </div>
    </div> -->
</div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/adminScripts/CRUD.js')); ?>"></script> <!-- Link ke file JavaScript eksternal -->
</body>
</html>
<?php /**PATH C:\rsud\hospital-management\resources\views/admin/CRUDObat.blade.php ENDPATH**/ ?>