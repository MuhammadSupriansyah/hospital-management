<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kadaluarsa extends Model
{
    // use HasFactory;
    // protected $table = 'kadaluarsa';
    // protected $fillable =[
    //     'tanggal_kadaluarsa',
    //     'stok'
    // ];
}

