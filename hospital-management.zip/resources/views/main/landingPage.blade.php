<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIPTEK-Landing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #003cff;
        }
        nav img {
            height: 50px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        nav ul li {
            margin: 0 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
        }
        nav ul li a:hover {
            color: #ddd;
        }

        body {
            background-image: url('{{ asset('img/rumahsakit.jpg') }}');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
        }

        #banner {
            background-color: rgba(0, 0, 0, 0.6); 
            padding: 80px 0;
        }

        footer {
            background-color: #002b5c; 
            color: white;
        }
    </style>
        </head>
        <body>

        </head>
        <body>
            <nav>
                <div>
                    <img src="{{asset('img/rshdLogo.png')}}" alt="Logo">
                    <span class="text-white ms-2" style="font-size: 24px; font-weight: bold;">SIPTEKin</span>
                </div>
                <ul>
                    <li><a href="{{route('landingPage')}}">BERANDA</a></li>
                    <li><a href="{{route('mitraKami')}}">MITRA KAMI</a></li>
                    <li><a href="{{route('tentangObat')}}">TENTANG OBAT</a></li>
                    <li><a href="{{route('panduan')}}">PANDUAN</a></li>
                </ul>
            </nav>
        </body>
        </html>

<main>
    <section id="banner" class="bg-primary text-white text-center py-5">
        <div class="container">
            <h1>SIPTEK</h1>
            <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                    <!-- Carousel Indicators -->
                    <div class="carousel-indicators">
                        @foreach ($carousels as $key => $carousel)
                            <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="{{ $key }}" class="{{ $key === 0 ? 'active' : '' }}" aria-label="Slide {{ $key + 1 }}"></button>
                        @endforeach
                    </div>

                    <!-- Carousel Items -->
                    <div class="carousel-inner">
                        @foreach ($carousels as $key => $carousel)
                            <div class="carousel-item {{ $key === 0 ? 'active' : '' }} mb-5">
                                <h3>{{ $carousel->title }}</h3>
                                <p>{!! nl2br(e($carousel->description)) !!}</p>
                            </div>
                        @endforeach
                    </div>

                    <!-- Carousel Controls -->
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </section>
</main>

    <footer class="text-center py-3">
        <div class="container-fluid text-center py-4">
            <div class="row">
                <h4>SIPTEKIN AJA!</h4>
                <div class="col-md-4">
                    <h5>Mitra Kami</h5>
                    <ul class="list-unstyled " id = "list">
                        <li><a href="https://www.instagram.com/poliban_official/" class="text-white">POLITEKNIK NEGERI BANJARMASIN</a></li>
                        <li><a href="{{route('login')}}" class="text-white">Admin</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>About Us</h5>
                    <ul class="list-unstyled" id="list">
                        <li><a href="#" class="text-white">Yang Membuat Web ini :</a></li>
                        <li><a href="https://www.instagram.com/supriansyaahh/" class="text-white">MUHAMMAD SUPRIANSYAH - C030322065</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact Person</h5>
                    <ul class="list-unstyled" id="list">
                        <li><a href="https://wa.me/6281351750693" class="text-white">+62-8135-1750-693</a></li>
                    </ul>
                </div>
            </div>
            <div class="d-flex justify-content-center mt-3" id="listGambar">
            <a href="https://play.google.com/store/games?device=windows" class="d-block mt-4">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                        alt="Get it on Google Play" class="img-fluid" style="max-width: 200px;">
                </a>
                <a href="#" class="ms-3"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Download_on_the_App_Store_Badge.svg/1280px-Download_on_the_App_Store_Badge.svg.png" alt="Download on the App Store" style="width: 130px; margin-top: 10px;"></a>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        footer {
        background-color: #003cff; 
        color: #ffffff; 
        padding: 40px 0;
        font-family: Arial, sans-serif;
        }

        footer h4 {
        margin-bottom: 20px;
        }

        footer h5, #list {
            text-align: left;
            padding-left: 90px;
        }

        footer a {
        color: #ffffff;  
        text-decoration: none;
        }

        footer a:hover {
        text-decoration: underline;
        }

        footer .container-fluid {
        max-width: 1200px;
        }

        footer ul {
        list-style: none;
        padding: 0;
        text-align: left;
        }

        footer ul li {
        margin-bottom: 10px;
        }

        footer .d-flex img {
        width: 140px;
        }

        footer .d-flex img:first-child {
        margin-right: 15px;
        }

        footer, #listGambar{
            justify-content: center;
        }

        nav a:hover {
            background-color: white;
            color: #003cff !important;
            padding: 10px 20px;
            border-radius: 30px;
            transition: background-color 0.3s, color 0.3s;
        }

</style>
